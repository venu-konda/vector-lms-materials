.\rtx_config.o: RTX_Config.c
.\rtx_config.o: C:\Keil4ARM\ARM\RV31\INC\RTL.h
.\rtx_config.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.H
.\rtx_config.o: C:\Keil4ARM\ARM\RV31\INC\RTX_lib.c
