/*
  CPU:LPC2148
  XTAL:12MHz,CCLOCK=60MHz
	RTOS Kernel: RTX
  AIM: Write an application that creates a two task to Blinking two different LEDs
     	 at different timings				
  CODE
*/	

#include <RTL.h>    /* RTX kernel functions & defines      */
#include <LPC214x.h>
#define LED1 1<<0  //led1 at P0.0 pin
#define LED2 1<<7  //led1 at P0.7 pin

/* id1, id2 will contain task identifications at run-time */
OS_TID id1, id2;

/* Forward reference */
__task void task1 (void);
__task void task2 (void);

void toggle_led(unsigned int ledNo);


/*----------------------------------------------------------------------------
 *        Main: Initialize and start RTX Kernel
 *---------------------------------------------------------------------------*/
int main (void) 
{
	IODIR0=LED1|LED2;
  os_sys_init (task1);
}

/*----------------------------------------------------------------------------
 *   Task 1:  RTX Kernel starts this task with os_sys_init (task1)
 *---------------------------------------------------------------------------*/
__task void task1 (void) 
{
  /* Obtain own system task identification number */
  id1 = os_tsk_self ();
  /* Assign system identification number of task2 to id2 */
  id2 = os_tsk_create (task2, 1);
  for (;;) 
	{
		toggle_led(LED1);
    os_dly_wait (20);//wait on timer for 10 tick=20*10ms
  }
}

/*----------------------------------------------------------------------------
 *   Task 2:  RTX Kernel starts this task with os_tsk_create (task2, 1)
 *---------------------------------------------------------------------------*/
__task void task2 (void) 
{
  for (;;) 
	{
		toggle_led(LED2);
    os_dly_wait (50);//wait on timer for 10 tick=50*10ms
  }
}


void toggle_led(unsigned int ledNo)
{
	if(IOSET0&ledNo)
		IOCLR0=ledNo;
	else
		IOSET0=ledNo;
}


