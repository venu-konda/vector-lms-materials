
#include <RTL.h>    /* RTX kernel functions & defines      */

/* id1, id2 will contain task identifications at run-time */
OS_TID id1, id2;

unsigned int flag;

/* Forward reference */
__task void task1 (void);
__task void task2 (void);


/*----------------------------------------------------------------------------
 *        Main: Initialize and start RTX Kernel
 *---------------------------------------------------------------------------*/
int main (void) 
{
	
  os_sys_init (task1);
	flag=0;
	while(1)
	{
		flag++;
  }		
}
/*----------------------------------------------------------------------------
 *   Task 1:  RTX Kernel starts this task with os_sys_init (task1)
 *---------------------------------------------------------------------------*/
__task void task1 (void) 
{
  /* Obtain own system task identification number */
  id1 = os_tsk_self ();
  /* Assign system identification number of task2 to id2 */
  id2 = os_tsk_create (task2, 1);
  for (;;) 
	{
    os_dly_wait (10);//wait on timer for 10 tick=10*10ms
		flag++;
		if(flag==15)
			os_tsk_delete(id2);
		if(flag==20)
			os_tsk_delete_self();
  }
}

/*----------------------------------------------------------------------------
 *   Task 2:  RTX Kernel starts this task with os_tsk_create (task2, 1)
 *---------------------------------------------------------------------------*/
__task void task2 (void) 
{
  for (;;) 
	{
    os_dly_wait (10);//wait on timer for 10 tick=10*10ms
  }
}



