#include <RTL.h>    /* RTX kernel functions & defines      */
#include <LPC214x.h>
#include "uart.h"

/* id1, id2 will contain task identifications at run-time */
OS_TID id1, id2;

/* Forward reference */
__task void task1 (void);
__task void task2 (void);

typedef struct        /* Message object structure            */
{                      
  unsigned char msgid;
	unsigned int i;
} MSG_QUEUE;
/* Declare an RTX mailbox  for 1 messages*/
os_mbx_declare (MsgQueue,1);

/* Reserve a memory of sizeof(MSG_QUEUE) bytes each for 1 block. */
_declare_box (mpool,sizeof(MSG_QUEUE),1); /* Dynamic memory pool    */


/*----------------------------------------------------------------------------
 *        Main: Initialize and start RTX Kernel
 *---------------------------------------------------------------------------*/
int main (void) 
{
	Init_UART0();
	_init_box (mpool, sizeof(mpool),    /* initialize the 'mpool' memory for   */
              sizeof(MSG_QUEUE));     /* the membox dynamic allocation       */
 
	os_sys_init (task1);
}

/*----------------------------------------------------------------------------
 *   Task 1:  RTX Kernel starts this task with os_sys_init (task1)
 *---------------------------------------------------------------------------*/
__task void task1 (void) 
{
	unsigned char RxChar=0;

	MSG_QUEUE *sendptr;

	/* Obtain own system task identification number */
  id1 = os_tsk_self ();
  /* Assign system identification number of task2 to id2 */
  id2 = os_tsk_create (task2, 1);
  os_mbx_init (MsgQueue, sizeof(MsgQueue));/* initialize the mailbox             */

	for (;;) 
	{
		RxChar=UART0_Rx_char();
		if(RxChar=='A')
	  {
			sendptr = _alloc_box (mpool);          /* Allocate a memory for the message   */
			sendptr->msgid=1;
			sendptr->i=RxChar; 
			os_mbx_send (MsgQueue, sendptr, 0xffff); /* Send the message to the mailbox     */
		
		}
		os_dly_wait (100);//wait on timer for 100 tick=100*10ms=1000ms

	}
}
/*----------------------------------------------------------------------------
 *   Task 2:  RTX Kernel starts this task with os_tsk_create (task2, 1)
 *---------------------------------------------------------------------------*/
__task void task2 (void) 
{
	MSG_QUEUE *recvptr;
	for (;;) 
	{
	
		UART0_Tx_str("waiting for message...\r\n");
    os_mbx_wait(MsgQueue, (void **)&recvptr, 0xffff); /* wait for the message    */
		UART0_Tx_str("Got Message with a msg id : ");
		UART0_Tx_int(recvptr->msgid);
	  UART0_Tx_str("\r\n Rxed Data is  : ");
		UART0_Tx_int(recvptr->i);
    UART0_Tx_str("\r\n");
		_free_box(mpool, recvptr);     // free memory allocated for message  */
  	
		os_dly_wait(100);//wait on timer for 100 tick=100*10ms=1000ms
  }
}


