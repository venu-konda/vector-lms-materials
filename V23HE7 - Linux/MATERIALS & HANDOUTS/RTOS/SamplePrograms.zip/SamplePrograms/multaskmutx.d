.\multaskmutx.o: MulTaskMutx.c
.\multaskmutx.o: C:\Keil4ARM\ARM\RV31\INC\RTL.h
.\multaskmutx.o: uart.h
