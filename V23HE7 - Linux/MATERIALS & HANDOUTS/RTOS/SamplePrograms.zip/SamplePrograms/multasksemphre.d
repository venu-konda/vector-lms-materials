.\multasksemphre.o: MulTaskSemPhre.c
.\multasksemphre.o: C:\Keil4ARM\ARM\RV31\INC\RTL.h
.\multasksemphre.o: uart.h
