.\multaskmsgqueue.o: MulTaskMsgQueue.c
.\multaskmsgqueue.o: C:\Keil4ARM\ARM\RV31\INC\RTL.h
.\multaskmsgqueue.o: C:\Keil4ARM\ARM\Inc\Philips\LPC214x.h
.\multaskmsgqueue.o: uart.h
