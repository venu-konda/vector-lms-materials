.\uart.o: uart.c
.\uart.o: C:\Keil4ARM\ARM\Inc\Philips\LPC214x.H
