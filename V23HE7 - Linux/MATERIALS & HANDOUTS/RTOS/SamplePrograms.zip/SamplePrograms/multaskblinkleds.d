.\multaskblinkleds.o: MulTaskBlinkLEDs.c
.\multaskblinkleds.o: C:\Keil4ARM\ARM\RV31\INC\RTL.h
.\multaskblinkleds.o: C:\Keil4ARM\ARM\Inc\Philips\LPC214x.h
