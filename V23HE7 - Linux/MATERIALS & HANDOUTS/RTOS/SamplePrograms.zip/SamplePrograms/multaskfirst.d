.\multaskfirst.o: MulTaskFirst.c
.\multaskfirst.o: C:\Keil4ARM\ARM\RV31\INC\RTL.h
