.\multaskprio.o: MulTaskPrio.c
.\multaskprio.o: C:\Keil4ARM\ARM\RV31\INC\RTL.h
