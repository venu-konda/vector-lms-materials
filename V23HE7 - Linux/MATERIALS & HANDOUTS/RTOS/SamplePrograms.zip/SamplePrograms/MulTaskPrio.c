/*
  CPU:LPC2148
  XTAL:12MHz,CCLOCK=60MHz
	RTOS Kernel: RTX
  AIM:To Create an application that creates two tasks */

#include <RTL.h>    /* RTX kernel functions & defines      */

/* id1, id2 will contain task identifications at run-time */
OS_TID id1, id2;

unsigned int cnt1,cnt2;

/* Forward reference */
__task void task1 (void);
__task void task2 (void);

/*----------------------------------------------------------------------------
 *        Main: Initialize and start RTX Kernel
 *---------------------------------------------------------------------------*/
int main (void) 
{
	
  os_sys_init (task1);
}
/*----------------------------------------------------------------------------
 *   Task 1:  RTX Kernel starts this task with os_sys_init (task1)
 *---------------------------------------------------------------------------*/
__task void task1 (void) 
{
  /* Obtain own system task identification number */
  id1 = os_tsk_self ();
  /* Assign system identification number of task2 to id2 */
  id2 = os_tsk_create (task2, 2);
  for (;;) 
	{
		cnt1++;
   // os_dly_wait (10);//wait on timer for 10 tick=10*10ms
  }
}

/*----------------------------------------------------------------------------
 *   Task 2:  RTX Kernel starts this task with os_tsk_create (task2, 1)
 *---------------------------------------------------------------------------*/
__task void task2 (void) 
{
  for (;;) 
	{
		cnt2++;
		//os_tsk_prio_self (2);
    //os_dly_wait (10);//wait on timer for 10 tick=10*10ms
  }
}



