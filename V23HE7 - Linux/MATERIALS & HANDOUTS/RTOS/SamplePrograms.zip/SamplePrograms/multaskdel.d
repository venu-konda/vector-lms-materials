.\multaskdel.o: MulTaskDel.c
.\multaskdel.o: C:\Keil4ARM\ARM\RV31\INC\RTL.h
