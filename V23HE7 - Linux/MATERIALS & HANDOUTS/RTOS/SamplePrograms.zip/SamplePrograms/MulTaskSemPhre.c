/*
  CPU:LPC2148
  XTAL:12MHz,CCLOCK=60MHz
	RTOS Kernel: RTX
  AIM:To Create an application that creates two tasks */

#include <RTL.h>    /* RTX kernel functions & defines      */
#include "uart.h"

/* id1, id2 will contain task identifications at run-time */
OS_TID id1, id2;
OS_SEM semaphore1;
unsigned int flag;

/* Forward reference */
__task void task1 (void);
__task void task2 (void);

/*----------------------------------------------------------------------------
 *        Main: Initialize and start RTX Kernel
 *---------------------------------------------------------------------------*/
int main (void) 
{
	Init_UART0();
  os_sys_init (task1);
}
/*----------------------------------------------------------------------------
 *   Task 1:  RTX Kernel starts this task with os_sys_init (task1)
 *---------------------------------------------------------------------------*/
__task void task1 (void) 
{
  /* Obtain own system task identification number */
  id1 = os_tsk_self ();
  /* Assign system identification number of task2 to id2 */
  id2 = os_tsk_create (task2, 1);
	os_sem_init (&semaphore1, 0);
	//	os_sem_send (&semaphore1);

  for (;;) 
	{
		os_sem_wait (&semaphore1, 0xffff);
		UART0_Tx_str("I am in Task1\r\n");
		os_sem_send (&semaphore1);
	  os_dly_wait (10);//wait on timer for 10 tick=10*10ms
  }
}

/*----------------------------------------------------------------------------
 *   Task 2:  RTX Kernel starts this task with os_tsk_create (task2, 1)
 *---------------------------------------------------------------------------*/
__task void task2 (void) 
{
  for (;;) 
	{
		os_sem_wait (&semaphore1, 0xffff);
		UART0_Tx_str("I am in Task2\r\n");
		os_sem_send (&semaphore1);
	  os_dly_wait (10);//wait on timer for 10 tick=10*10ms
  }
}



