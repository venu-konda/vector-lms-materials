                /* Demonstrating Timer 0 for time delay generations */
								
#include <LPC21xx.h>

typedef unsigned char u8;
typedef signed char   s8;
typedef unsigned short int  u16;
typedef signed short   int  s16;
typedef unsigned int  u32;
typedef signed   int  s32;
typedef float f32;
typedef double f64;

void InitTimer0(void)
{
	T0TCR = 0x02; //Reset Timer
	T0MCR = 0x0000004;//stop Timer Counter upon match
}

void tdelay_us(u32 microseconds) //Using Timer0
{
	T0MR0=microseconds;
	T0PR = 15-1; //PCLK/15=15MHz/15=1MHz,so T0TC increments every 1us	
	T0TC = 0;
	T0TCR = 0x01; //Enable timer
	while(T0TC!=T0MR0); //wait until timer attains desired delay
}

void tdelay_ms(u32 milliseconds) //Using Timer0
{
	T0MR0=milliseconds;
	T0PR = 15000-1; //PCLK/15000,15MHz/15000=1KHz=1000Hz
	                //so T0TC increments every 1000us/1ms         
	                  
	T0TC = 0;
	T0TCR = 0x01; //Enable timer
	while(T0TC!=T0MR0); //wait until timer counter 
                   //reaches the desired delay
}

void tdelay_s(u32 seconds) //Using Timer0
{
	T0MR0=seconds;
	T0PR = 15000000-1; //PCLK/15000000,15MHz/15000000=1Hz
	                   //so T0TC increments every 1000000us/1000ms/1s         
	T0TC = 0;
	T0TCR = 0x01; //Enable timer
	while(T0TC!=T0MR0); //wait until timer counter 
                   //reaches the desired delay
}

int main()
{
	 InitTimer0();
	 //tdelay_us(100000);
   tdelay_ms(500000);
	 tdelay_s(5);
   while(1);	
}
