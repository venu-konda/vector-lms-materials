                               /* timer_interrupts.c */
			 
#include <LPC21xx.h>
#include "types.h"
#include "defines.h"
                              /* timer_defines.h start */

//bit defines for T0TCR
#define TIMER0_ENABLE                 0x01
#define TIMER0_RST                    0x02

//bit defines for T0MCR
#define TIMER0_INT_ON_MR0             0x01
#define TIMER0_RST_ON_MR0             0x02
#define TIMER0_STOP_ON_MR0            0x04

//VIC Channel No for TIMER0
#define TIMER0_CHNO                   4
#define TIMER0_STATUS_LED             7 //p0.7 ,modify if required
//add more defines as required
                              /* timer_defines.h end */

void InitTimer0(void)
{
	T0TCR = TIMER0_RST; //Reset Timer
	T0MCR = TIMER0_STOP_ON_MR0;//stop Timer Counter upon match
}

void tdelay_us(u32 microseconds) //Using Timer0
{
	T0MR0=microseconds;
	T0PR = 15-1; //PCLK/15=15MHz/15=1MHz,so T0TC increments every 1us	
	T0TC = 0;
	T0TCR = TIMER0_ENABLE; //Enable timer
	while(T0TC!=T0MR0); //wait until timer attains desired delay
}

void tdelay_ms(u32 milliseconds) //Using Timer0
{
	T0MR0=milliseconds;
	T0PR = 15000-1; //PCLK/15000,15MHz/15000=1KHz=1000Hz
	                //so T0TC increments every 1000us/1ms         
	                  
	T0TC = 0;
	T0TCR = TIMER0_ENABLE; //Enable timer
	while(T0TC!=T0MR0); //wait until timer counter 
                   //reaches the desired delay
}

void tdelay_s(u32 seconds) //Using Timer0
{
	T0MR0=seconds;
	T0PR = 15000000-1; //PCLK/15000000,15MHz/15000000=1Hz
	                   //so T0TC increments every 1000000us/1000ms/1s         
	T0TC = 0;
	T0TCR = TIMER0_ENABLE; //Enable timer
	while(T0TC!=T0MR0); //wait until timer counter 
                   //reaches the desired delay
}


void timer0_isr(void) __irq
{
	 //start of user isr response
    CPLBIT(IOPIN0,TIMER0_STATUS_LED);  
	 //end of user isr response
    T0IR        = 1;   // Clear interrupt flag
   //add ur statement here 
    VICVectAddr = 0x00; //Dummy write to clear register 
}

void Enable_Timer0_Interrupt_US(u32 microseconds)
{
	SETBIT(IODIR0,TIMER0_STATUS_LED);
  T0MCR=TIMER0_INT_ON_MR0|TIMER0_RST_ON_MR0;
	// configuring VIC for Vectored IRQ TIMER0
	//Enable TIMER0 in the VIC
 	VICIntEnable = 1<<TIMER0_CHNO;

  VICVectCntl0 = 0x20|TIMER0_CHNO;	 
  VICVectAddr0 = (unsigned)timer0_isr;

	tdelay_us(microseconds);
}


int main()
{
    InitTimer0();
	Enable_Timer0_Interrupt_US(300000);
    while(1);	
}
