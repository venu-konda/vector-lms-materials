.\counter.o: counter.c
.\counter.o: C:\Keil4_ARM\ARM\Inc\Philips\LPC21xx.h
.\counter.o: defines.h
.\counter.o: timer_defines.h
