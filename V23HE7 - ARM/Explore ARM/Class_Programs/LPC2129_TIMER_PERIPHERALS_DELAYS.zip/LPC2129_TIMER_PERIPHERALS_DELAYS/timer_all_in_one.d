.\timer_all_in_one.o: Timer_All_In_One.c
.\timer_all_in_one.o: C:\Keil4_arm\ARM\Inc\Philips\LPC21xx.h
