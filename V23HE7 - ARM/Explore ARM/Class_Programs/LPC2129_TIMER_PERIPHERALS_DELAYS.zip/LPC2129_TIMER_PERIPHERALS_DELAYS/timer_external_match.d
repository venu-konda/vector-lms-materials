.\timer_external_match.o: timer_external_match.c
.\timer_external_match.o: C:\Keil4_ARM\ARM\Inc\Philips\LPC21xx.h
.\timer_external_match.o: types.h
.\timer_external_match.o: pin_function_defines.h
