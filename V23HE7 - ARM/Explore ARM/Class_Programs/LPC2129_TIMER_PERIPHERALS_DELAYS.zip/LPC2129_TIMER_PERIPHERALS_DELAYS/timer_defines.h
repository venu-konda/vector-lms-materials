                              /* timer_defines.h */

//bit defines for T0TCR
#define TIMER0_ENABLE                 0x01
#define TIMER0_RST                    0x02

//bit defines for T0MCR
#define TIMER0_RST_ON_MR0             0x02
#define TIMER0_STOP_ON_MR0            0x04

//bit defines for T0CTCR
#define TIMER0_COUNTERMODE_SELECT     0x02

