#define FUNC1 0
#define FUNC2 1
#define FUNC3 2
#define FUNC4 3

#define CFGPIN(WORD,PIN,FUNC) \
        (WORD=(PIN<16) ? \
        (WORD&~((unsigned)3<<(PIN*2))|(FUNC<<(PIN*2))) : \
		    (WORD&~((unsigned)3<<((PIN-16)*2))|(FUNC<<((PIN-16)*2))))


//p0.2  
#define TIMER0_CAP0_0_2 FUNC3

//p0.3
#define TIMER0_EMC0_0_3 FUNC3
            