.\timer0_capture_test.o: timer0_capture_test.c
.\timer0_capture_test.o: C:\Keil4_ARM\ARM\Inc\Philips\LPC21xx.h
.\timer0_capture_test.o: types.h
.\timer0_capture_test.o: pin_function_defines.h
