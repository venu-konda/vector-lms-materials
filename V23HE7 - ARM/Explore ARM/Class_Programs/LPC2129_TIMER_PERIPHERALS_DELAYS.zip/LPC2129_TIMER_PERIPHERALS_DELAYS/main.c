                /* Demonstrating Timer 0 for time delay generations */
								
#include <LPC21xx.h>

#include "timer.h"
#include "timer_defines.h"

int main()
{
    InitTimer0();//timer initialisation
	tdelay_us(1);//delay for 1000 microseconds
    tdelay_ms(1000);//delay for 1000 milliseconds
	tdelay_s(1);    //delay for 1 second
    while(1);	
}
