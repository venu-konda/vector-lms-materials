                               /* timer0_capture_test.c */
#include <LPC21xx.h>
#include "types.h"
//#include "defines.h"
#include "pin_function_defines.h"

//bit defines for T0TCR
#define TIMER0_ENABLE                 0x01
#define TIMER0_RST                    0x02

//bit defines for T0MCR
#define TIMER0_INT_ON_MR0             0x01
#define TIMER0_RST_ON_MR0             0x02
#define TIMER0_STOP_ON_MR0            0x04

//bit defines for T0CCR
#define TIMER0_CAP_REDGE              0x01
#define TIMER0_CAP_FEDGE              0x02

//add more defines as required

void Init_Timer0(void)
{
  CFGPIN(PINSEL0,2,TIMER0_CAP0_0_2);	
	T0TCR = TIMER0_RST; //Reset Timer
	T0MCR = TIMER0_STOP_ON_MR0;//stop Timer Counter upon match
	T0CCR = TIMER0_CAP_FEDGE|TIMER0_CAP_REDGE;
}

void tdelay_us(u32 microseconds) //Using Timer0
{
	T0MR0=microseconds;
	T0PR = 15-1; //PCLK/15=15MHz/15=1MHz,so T0TC increments every 1us	
	T0TC = 0;
	T0TCR = TIMER0_ENABLE; //Enable timer
	while(T0TC!=T0MR0); //wait until timer attains desired delay
}

void tdelay_ms(u32 milliseconds) //Using Timer0
{
	T0MR0=milliseconds;
	T0PR = 15000-1; //PCLK/15000,15MHz/15000=1KHz=1000Hz
	                //so T0TC increments every 1000us/1ms         
	                  
	T0TC = 0;
	T0TCR = TIMER0_ENABLE; //Enable timer
	while(T0TC!=T0MR0); //wait until timer counter 
                   //reaches the desired delay
}

void tdelay_s(u32 seconds) //Using Timer0
{
	T0MR0=seconds;
	T0PR = 15000000-1; //PCLK/15000000,15MHz/15000000=1Hz
	                   //so T0TC increments every 1000000us/1000ms/1s         
	T0TC = 0;
	T0TCR = TIMER0_ENABLE; //Enable timer
	while(T0TC!=T0MR0); //wait until timer counter 
                   //reaches the desired delay
}

int main()
{
    Init_Timer0();
    tdelay_s(1000);
    while(1);	
}
