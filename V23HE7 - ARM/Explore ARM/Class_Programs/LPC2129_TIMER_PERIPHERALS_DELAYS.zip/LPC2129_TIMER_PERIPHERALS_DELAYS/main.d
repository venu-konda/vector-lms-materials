.\main.o: main.c
.\main.o: C:\Keil4_ARM\ARM\Inc\Philips\LPC21xx.h
.\main.o: timer.h
.\main.o: types.h
.\main.o: timer_defines.h
