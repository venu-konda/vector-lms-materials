.\timer_interrupts.o: timer_interrupts.c
.\timer_interrupts.o: C:\Keil4_ARM\ARM\Inc\Philips\LPC21xx.h
.\timer_interrupts.o: types.h
.\timer_interrupts.o: defines.h
