.\timer.o: timer.c
.\timer.o: C:\Keil4_ARM\ARM\Inc\Philips\LPC21xx.h
.\timer.o: types.h
.\timer.o: timer_defines.h
