/* refer the LPC2129_new manual for counter operation related register information */
#include <LPC21xx.h>

#include "defines.h"
#include "timer_defines.h"

#define T0CTCR (*((volatile unsigned long *) 0xE0004070))  //T0CTCR register address
    
unsigned int count=0;  //global variable declaration along with initialisation

#define LEDS 8  //8 leds are connected to P0.8-P0.15 (AL:P0.8-P0.11 & AH:P0.12-P0.15) 


int main()
{	   
	PINSEL0 |= 0x00000020;  //configure the P0.2 as CAP0.0 funtionality 
        
    WRITEBYTE(IODIR0,LEDS,0xFF); //set the data direction of P0.8-P0.15 as output port
    
	T0TCR = TIMER0_RST;  //reset the timer
	T0TCR = TIMER0_ENABLE;  //Enable timer    
	T0CTCR = TIMER0_COUNTERMODE_SELECT;    //set Counter Mode: TC is incremented on falling edges on the CAP0.0 (P0.2)

    
	while(1)
	{
		count = T0TC;	//reading the external events from timer count register and updated to count variable
        WRITEBYTE(IOPIN0,LEDS,(count^0x0F));  //display binary equivalent of count value on LEDS upto 255
	}	
}
