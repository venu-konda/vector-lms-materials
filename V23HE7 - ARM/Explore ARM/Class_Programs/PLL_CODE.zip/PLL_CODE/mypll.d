.\mypll.o: mypll.c
.\mypll.o: C:\Keil4_ARM\ARM\Inc\Philips\LPC21xx.H
