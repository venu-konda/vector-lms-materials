.\serialize_in.o: serialize_in.c
.\serialize_in.o: delay.h
.\serialize_in.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\serialize_in.o: defines.h
