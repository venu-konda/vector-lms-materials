.\gpio_3a.o: gpio_3a.c
.\gpio_3a.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_3a.o: delay.h
