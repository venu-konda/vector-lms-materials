.\gpio_1d.o: gpio_1d.c
.\gpio_1d.o: delay.h
.\gpio_1d.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
