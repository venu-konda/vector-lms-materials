//serialize_in1.c
#include "delay.h"
#include <LPC21xx.h>
#include "defines.h"
#define IPIN 1 //p0.1

main()
{
	int i; unsigned char rDat;
	//cfg p0.1 as gpio in pin
	//CLRBIT(IODIR0,IPIN);
	//cfg p0.0 as gpio out pin
	SETBIT(IODIR0,0); 
	for(i=7;i>=0;i--)
	{
		//delay_us(104);
	  READWRITEBIT(rDat,i,IOPIN0,IPIN);
	}
	if(rDat=='A')
	  CPLBIT(IOPIN0,0);
	while(1);
}
