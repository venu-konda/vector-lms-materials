.\software_delay_test.o: software_delay_test.c
.\software_delay_test.o: delay.h
