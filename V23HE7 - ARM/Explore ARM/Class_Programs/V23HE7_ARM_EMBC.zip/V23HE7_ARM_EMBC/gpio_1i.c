//gpio_1i.c
#include "delay.h"
#include <LPC21xx.h>
#include "defines.h"
#define OPIN 7
main()
{
	//cfg p0.7 as gpio out pit
	SETBIT(IODIR0,OPIN);
	while(1)
	{
	 //write '1' onto pin
	 WRITEBIT(IOSET0,OPIN,1);	
	 delay_ms(100);
	 //write '0' onto pin
	 WRITEBIT(IOCLR0,OPIN,1);	
	 delay_ms(100);
			
	}
}
