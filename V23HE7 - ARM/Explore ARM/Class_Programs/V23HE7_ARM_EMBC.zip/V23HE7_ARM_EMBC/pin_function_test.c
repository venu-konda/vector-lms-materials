//pin_function_cfg.c
#include <LPC21xx.h>

main()
{
	PINSEL0=0<<2|0<<0;
	PINSEL0=1<<2|1<<0;
	PINSEL0=2<<2|2<<0;
	PINSEL0=3<<2|3<<0;
	while(1);
}
