.\pin_function_defines.o: pin_function_defines.c
.\pin_function_defines.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\pin_function_defines.o: pin_function_defines.h
