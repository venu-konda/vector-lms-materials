//gpio_1l.c
#include "delay.h"
#include <LPC21xx.h>
#include "defines.h"
#define OPIN 7
main()
{
	//cfg p0.7 as gpio out pit
	SETBIT(IODIR0,OPIN);
	while(1)
	{
	  WRITEBIT(IOPIN0,OPIN,!READBIT(IOPIN0,OPIN));	
	  delay_ms(100);
	}
}
