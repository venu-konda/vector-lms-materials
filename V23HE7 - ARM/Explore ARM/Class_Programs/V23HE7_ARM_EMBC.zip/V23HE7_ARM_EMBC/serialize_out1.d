.\serialize_out1.o: serialize_out1.c
.\serialize_out1.o: delay.h
.\serialize_out1.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\serialize_out1.o: defines.h
