.\sws4_al_leds4_al_1.o: SWs4_AL_LEDs4_AL_1.c
.\sws4_al_leds4_al_1.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\sws4_al_leds4_al_1.o: defines.h
.\sws4_al_leds4_al_1.o: types.h
