#include <LPC21xx.h>
#include "types.h"
#include "delay.h"

#define OPORT 8//p0.8 to p0.15

main()
{
	u32 i;
	//PINSEL0=(PINSEL0&~(0xffff<<8));
	//cfg p0.8 to p0.15 pins as gpio out
	IODIR0|=0xFF<<OPORT;
	for(i=0;i<=255;i++)
	{
		IOPIN0=i<<OPORT;
		delay_ms(100);
	}
	while(1);
}
