//gpio_2a.c flash some gpio pins@100ms
#include <LPC21xx.h>
#include "delay.h"
main()
{
	//cfg p0.0,0.15 p0.27-p0.30.p1.16,1.31 as gpio pin func
	//default all other are any way gpio
	PINSEL1=0;
	
	//cfg all port pins as gpio out pins
	IODIR0=(1<<0)|(1<<15)|(1<<27)|(1<<28)|(1<<29)|(1<<30);
	IODIR1=(1<<16)|(1<<31);
	
	while(1)
	{
		IOPIN0^=(1<<0)|(1<<15)|(1<<27)|(1<<28)|(1<<29)|(1<<30);
		IOPIN1^=(1<<16)|(1<<31);
		delay_ms(100);
	}
	
}
