.\gpio_hal.o: gpio_hal.c
.\gpio_hal.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_hal.o: types.h
.\gpio_hal.o: defines.h
.\gpio_hal.o: pin_function_defines.h
