.\pattern_0_to_255c.o: pattern_0_to_255c.c
.\pattern_0_to_255c.o: types.h
.\pattern_0_to_255c.o: delay.h
.\pattern_0_to_255c.o: types.h
.\pattern_0_to_255c.o: pin_function_defines.h
.\pattern_0_to_255c.o: gpio_hal.h
.\pattern_0_to_255c.o: types.h
