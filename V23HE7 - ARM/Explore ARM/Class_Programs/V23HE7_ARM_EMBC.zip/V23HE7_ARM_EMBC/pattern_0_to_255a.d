.\pattern_0_to_255a.o: pattern_0_to_255a.c
.\pattern_0_to_255a.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\pattern_0_to_255a.o: types.h
.\pattern_0_to_255a.o: delay.h
.\pattern_0_to_255a.o: types.h
