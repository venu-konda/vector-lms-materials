.\gpio_1k.o: gpio_1k.c
.\gpio_1k.o: delay.h
.\gpio_1k.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_1k.o: defines.h
