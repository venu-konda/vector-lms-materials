.\gpio_2a.o: gpio_2a.c
.\gpio_2a.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_2a.o: delay.h
