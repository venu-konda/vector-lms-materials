.\sws4_al_leds4_al_3.o: SWs4_AL_LEDs4_AL_3.c
.\sws4_al_leds4_al_3.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\sws4_al_leds4_al_3.o: pin_function_defines.h
.\sws4_al_leds4_al_3.o: gpio_hal.h
.\sws4_al_leds4_al_3.o: types.h
