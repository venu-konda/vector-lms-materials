//gpio_1h.c
#include "delay.h"
#include <LPC21xx.h>
#include "defines.h"
#define OPIN 7
main()
{
	//cfg p0.7 as gpio out pit
	SETBIT(IODIR0,OPIN);
	while(1)
	{
	 //write '1' onto pin
	 SSETBIT(IOSET0,OPIN);	
	 delay_ms(100);
	 //write '0' onto pin
	 SCLRBIT(IOCLR0,OPIN);	
	 delay_ms(100);
			
	}
}
