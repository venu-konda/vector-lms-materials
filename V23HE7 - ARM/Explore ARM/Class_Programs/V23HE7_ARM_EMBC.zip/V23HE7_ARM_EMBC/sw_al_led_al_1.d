.\sw_al_led_al_1.o: SW_AL_LED_AL_1.c
.\sw_al_led_al_1.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
