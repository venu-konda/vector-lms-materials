//pin_function_cfg_3.c
#include <LPC21xx.h>
#include "pin_function_defines.h"
main()
{
	//cfg p0.7 pin for func4
	PINSEL0=(PINSEL0&~(3<<(7*2)))|(FUNC4<<(7*2));
	
	//re-cfg p0.7 pin for func3
	PINSEL0=(PINSEL0&~(3<<(7*2)))|(FUNC3<<(7*2));

	//re-cfg p0.7 pin for func2
	PINSEL0=(PINSEL0&~(3<<(7*2)))|(FUNC2<<(7*2));

	//re-cfg p0.7 pin for func1
	PINSEL0=(PINSEL0&~(3<<(7*2)))|(FUNC1<<(7*2));

	CFGPIN(PINSEL0,7,FUNC4);
	CFGPIN(PINSEL0,7,FUNC3);
	CFGPIN(PINSEL0,7,FUNC2);
	CFGPIN(PINSEL0,7,FUNC1);
	
	//cfg p0.16 pin for func4
	PINSEL1=(PINSEL1&~(3<<((16-16)*2)))|(FUNC4<<((16-16)*2));
	
	CFGPIN(PINSEL1,16,FUNC3);
	CFGPIN(PINSEL1,16,FUNC2);
	CFGPIN(PINSEL1,16,FUNC1);
	
	
}
