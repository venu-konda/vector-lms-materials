.\gpio_3.o: gpio_3.c
.\gpio_3.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_3.o: delay.h
