.\gpio_1.o: gpio_1.c
.\gpio_1.o: pin_function_defines.h
.\gpio_1.o: delay.h
.\gpio_1.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
