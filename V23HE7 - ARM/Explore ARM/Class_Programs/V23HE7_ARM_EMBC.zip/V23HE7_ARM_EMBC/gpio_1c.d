.\gpio_1c.o: gpio_1c.c
.\gpio_1c.o: delay.h
.\gpio_1c.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
