.\gpio_1i.o: gpio_1i.c
.\gpio_1i.o: delay.h
.\gpio_1i.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_1i.o: defines.h
