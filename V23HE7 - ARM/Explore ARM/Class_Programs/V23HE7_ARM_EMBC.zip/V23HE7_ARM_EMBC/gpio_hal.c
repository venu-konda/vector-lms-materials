//gpio_hal.c
#include <LPC21xx.h>
#include "types.h"
#include "defines.h"
#include "pin_function_defines.h"

void CfgPortPin(u32 portNo,u32 pinNo,u32 pinFunc)
{
  if(portNo==0)
  {
		if(pinFunc==GPIO_IN) 
		{ CLRBIT(IODIR0,pinNo); pinFunc=FUNC1; }
		else if(pinFunc==GPIO_OUT) 
		{ SETBIT(IODIR0,pinNo); pinFunc=FUNC1; }
    if(pinNo<16) CFGPIN(PINSEL0,pinNo,pinFunc);
    else if((pinNo>=16) && (pinNo<=31))
      CFGPIN(PINSEL1,(pinNo-16),pinFunc);  		
  }
  else if(portNo==1)
  {
		if(pinFunc==GPIO_IN) 
		{ CLRBIT(IODIR1,pinNo); pinFunc=FUNC1; }
		else if(pinFunc==GPIO_OUT) 
		{ SETBIT(IODIR1,pinNo); pinFunc=FUNC1; }
    if((pinNo>=16) && (pinNo<=31))
      CFGPIN(PINSEL2,(pinNo-16),pinFunc);  		
  }		
}

void SetPortPin(u32 portNo,u32 pinNo)
{
	(portNo==0) ? 
	SSETBIT(IOSET0,pinNo) : SSETBIT(IOSET1,pinNo);
}

void ClrPortPin(u32 portNo,u32 pinNo)
{
	(portNo==0) ? 
	SCLRBIT(IOCLR0,pinNo) : SCLRBIT(IOCLR1,pinNo);
}

void TogglePortPin(u32 portNo,u32 pinNo)
{
	(portNo==0) ? 
	CPLBIT(IOPIN0,pinNo) : CPLBIT(IOPIN1,pinNo);
}

void Wr2PortPin(u32 portNo,u32 pinNo,u32 bit)
{
 (portNo==0) ? 
	WRITEBIT(IOPIN0,pinNo,bit) : WRITEBIT(IOPIN1,pinNo,bit);
}

u32 RdPortPin(u32 portNo,u32 pinNo)
{
	return (portNo==0) ? 
	READBIT(IOPIN0,pinNo) : READBIT(IOPIN1,pinNo);
}

void CfgPortByte(u32 portNo,u32 startPinNo,u32 pinFunc)
{
  if(portNo==0)
  {
		if(pinFunc==GPIO_IN) 
		{ WRITEBYTE(IODIR0,startPinNo,0x00); pinFunc=FUNC1; }
		else if(pinFunc==GPIO_OUT) 
		{ WRITEBYTE(IODIR0,startPinNo,0xFF); pinFunc=FUNC1; }
    if(startPinNo<16) 
			PINSEL0=(PINSEL0&~(0xFFFF<<(startPinNo*2)));
    else if((startPinNo>=16) && (startPinNo<=31))
      PINSEL1=(PINSEL1&~(0xFFFF<<((startPinNo-16)*2))); 		
  }
  else if(portNo==1)
  {
		if(pinFunc==GPIO_IN) 
		{ WRITEBYTE(IODIR1,startPinNo,0x00); pinFunc=FUNC1; }
		else if(pinFunc==GPIO_OUT) 
		{ WRITEBYTE(IODIR1,startPinNo,0xFF); pinFunc=FUNC1; }
    if((startPinNo>=16) && (startPinNo<=31))
      PINSEL2=(PINSEL2&~(0xFFFF<<((startPinNo-16)*2)));  		
  }		
}

void Wr2PortByte(u32 portNo,u32 startPinNo,u32 byte)
{
 (portNo==0) ? 
 WRITEBYTE(IOPIN0,startPinNo,byte) : 
 WRITEBYTE(IOPIN1,startPinNo,byte);
}

u8 RdPortByte(u32 portNo,u32 startPinNo)
{
 return (portNo==0) ? 
 READBYTE(IOPIN0,startPinNo) : 
 READBYTE(IOPIN1,startPinNo);
}

