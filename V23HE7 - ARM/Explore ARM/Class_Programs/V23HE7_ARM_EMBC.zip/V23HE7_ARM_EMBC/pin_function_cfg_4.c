//pin_function_cfg_4.c
#include "pin_function_defines.h"									
main()
{
	//cfg p0.7 pin for func4
	CfgPortPin(0,7,FUNC4);
	CfgPortPin(0,7,FUNC3);
	CfgPortPin(0,7,FUNC2);
	CfgPortPin(0,7,FUNC1);
	
	while(1);
}
