.\gpio_1m.o: gpio_1m.c
.\gpio_1m.o: delay.h
.\gpio_1m.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_1m.o: defines.h
