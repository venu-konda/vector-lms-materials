.\sws4_al_leds4_al.o: SWs4_AL_LEDs4_AL.c
.\sws4_al_leds4_al.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
