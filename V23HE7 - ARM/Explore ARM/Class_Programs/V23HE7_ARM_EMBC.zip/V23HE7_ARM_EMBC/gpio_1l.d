.\gpio_1l.o: gpio_1l.c
.\gpio_1l.o: delay.h
.\gpio_1l.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_1l.o: defines.h
