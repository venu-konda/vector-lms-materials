.\test.o: test.c
