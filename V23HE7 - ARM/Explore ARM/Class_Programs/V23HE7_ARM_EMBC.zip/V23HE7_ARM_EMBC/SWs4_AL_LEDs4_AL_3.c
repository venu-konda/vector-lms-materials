//SWs4_AL_LEDs4_AL_3.c
#include <LPC21xx.h>
#include "pin_function_defines.h"
#include "gpio_hal.h"

#define SWs4_AL_0_4  4  //p0.4- p0.7
#define LEDs4_AL_0_8 8  //p0.8 -p0.11
u8 t;
main()
{

	//cfg p0.8 to p0.11 pins as gpio out
	CfgPortPin(0,LEDs4_AL_0_8,GPIO_OUT);
	CfgPortPin(0,LEDs4_AL_0_8+1,GPIO_OUT);
	CfgPortPin(0,LEDs4_AL_0_8+2,GPIO_OUT);
	CfgPortPin(0,LEDs4_AL_0_8+3,GPIO_OUT);
	
	while(1)
	{
		t=RdPortByte(0,SWs4_AL_0_4);
		Wr2PortByte(0,LEDs4_AL_0_8,t);
	}
}
