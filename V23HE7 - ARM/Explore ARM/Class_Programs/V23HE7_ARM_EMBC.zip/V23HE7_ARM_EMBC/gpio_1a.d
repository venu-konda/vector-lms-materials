.\gpio_1a.o: gpio_1a.c
.\gpio_1a.o: pin_function_defines.h
.\gpio_1a.o: delay.h
.\gpio_1a.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
