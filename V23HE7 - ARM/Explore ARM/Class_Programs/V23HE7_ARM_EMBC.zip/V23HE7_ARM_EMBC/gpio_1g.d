.\gpio_1g.o: gpio_1g.c
.\gpio_1g.o: delay.h
.\gpio_1g.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
