//pin_function_cfg_5.c
#include "pin_function_defines.h"									
main()
{
	//cfg p0.7 pin 
	CfgPin(7,FUNC4);
	CfgPin(7,FUNC3);
	CfgPin(7,FUNC2);
	CfgPin(7,FUNC1);
	
	//cfg p0.16 pin 
	CfgPin(16,FUNC4);
	CfgPin(16,FUNC3);
	CfgPin(16,FUNC2);
	CfgPin(16,FUNC1);

	//cfg p0.27 pin 
	CfgPin(27,FUNC4);
	CfgPin(27,FUNC3);
	CfgPin(27,FUNC2);
	CfgPin(27,FUNC1);
	
	//cfg p0.30
	CFGPIN(PINSEL1,30,FUNC4);
	CfgPortPin(0,30,FUNC3);
	CfgPin(30,FUNC2);
	
	while(1);
}
