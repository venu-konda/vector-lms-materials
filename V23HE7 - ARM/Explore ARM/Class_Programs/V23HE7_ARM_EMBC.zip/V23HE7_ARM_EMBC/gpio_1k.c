//gpio_1k.c
#include "delay.h"
#include <LPC21xx.h>
#include "defines.h"
#define OPIN 7
main()
{
	unsigned int t=0;
	//cfg p0.7 as gpio out pit
	SETBIT(IODIR0,OPIN);
	while(1)
	{
	  WRITEBIT(IOPIN0,OPIN,t=!t);	
	  delay_ms(100);
	}
}
