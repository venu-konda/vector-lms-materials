.\pin_function_cfg5.o: pin_function_cfg5.c
.\pin_function_cfg5.o: pin_function_defines.h
