//pattern_0_to_255c.c
#include "types.h"
#include "delay.h"
#include "pin_function_defines.h"
#include "gpio_hal.h"

#define OPORT 16//p0.8 to p0.15

main()
{
	u32 i;
	CfgPortByte(0,OPORT,GPIO_OUT);
	for(i=0;i<=255;i++)
	{
		Wr2PortByte(0,OPORT,i);
		delay_ms(100);
	}
	while(1);
}
