.\pin_function_cfg_4.o: pin_function_cfg_4.c
.\pin_function_cfg_4.o: pin_function_defines.h
