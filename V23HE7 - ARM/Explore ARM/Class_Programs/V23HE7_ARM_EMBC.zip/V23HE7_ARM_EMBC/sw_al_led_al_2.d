.\sw_al_led_al_2.o: SW_AL_LED_AL_2.c
.\sw_al_led_al_2.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
