.\gpio_1h.o: gpio_1h.c
.\gpio_1h.o: delay.h
.\gpio_1h.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_1h.o: defines.h
