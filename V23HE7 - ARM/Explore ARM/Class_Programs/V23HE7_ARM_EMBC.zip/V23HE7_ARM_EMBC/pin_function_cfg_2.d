.\pin_function_cfg_2.o: pin_function_cfg_2.c
.\pin_function_cfg_2.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\pin_function_cfg_2.o: pin_function_defines.h
