.\sw_al_led_al_4.o: SW_AL_LED_AL_4.c
.\sw_al_led_al_4.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
