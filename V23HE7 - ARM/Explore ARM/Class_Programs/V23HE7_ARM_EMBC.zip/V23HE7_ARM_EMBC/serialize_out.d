.\serialize_out.o: serialize_out.c
.\serialize_out.o: delay.h
.\serialize_out.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\serialize_out.o: defines.h
