//gpio_2.c flash all gpio pins@100ms
#include <LPC21xx.h>
#include "delay.h"
#include "pin_function_defines.h"
main()
{
	//cfg p0.27-p0.30 as gpio pin func
	//default all other are any way gpio
	CFGPIN(PINSEL1,27,FUNC1);
	CFGPIN(PINSEL1,28,FUNC1);
	CFGPIN(PINSEL1,29,FUNC1);
	CFGPIN(PINSEL1,30,FUNC1);
	
	//cfg all port pins as gpio out pins
	IODIR0=0xFFFFFFFF;
	IODIR1=0xFFFF0000;
	
	while(1)
	{
		IOSET0=0xFFFFFFFF;
		IOSET1=0xFFFF0000;
		delay_ms(100);
		IOCLR0=0xFFFFFFFF;
		IOCLR1=0xFFFF0000;
		delay_ms(100);
		
	}
	
}
