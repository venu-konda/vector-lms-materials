//SW_AL_LED_AL_2.c
#include <LPC21xx.h>
#define SW_AL_0_4  4  //p0.4
#define LED_AL_0_7 7  //p0.7
main()
{
	//cfg p0.7 pin as gpio out
	IODIR0|=1<<LED_AL_0_7;
	
	while(1)
	{
		(((IOPIN0>>SW_AL_0_4)&1)==0) ? (IOCLR0=1<<LED_AL_0_7) : (IOSET0=1<<LED_AL_0_7) ;
	}
}
