.\pattern_0_to_255.o: pattern_0_to_255.c
.\pattern_0_to_255.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\pattern_0_to_255.o: types.h
.\pattern_0_to_255.o: delay.h
.\pattern_0_to_255.o: types.h
