.\sw_al_led_al_3.o: SW_AL_LED_AL_3.c
.\sw_al_led_al_3.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
