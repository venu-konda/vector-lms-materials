//pattern_0_to_255b.c
#include <LPC21xx.h>
#include "types.h"
#include "delay.h"
#include "defines.h"

#define OPORT 8//p0.8 to p0.15

main()
{
	u32 i;
	//PINSEL0=(PINSEL0&~(0xffff<<8));
	//cfg p0.8 to p0.15 pins as gpio out
	WRITEBYTE(IODIR0,OPORT,0xFF);
	for(i=0;i<=255;i++)
	{
		WRITEBYTE(IOPIN0,OPORT,i);
		delay_ms(100);
	}
	while(1);
}
