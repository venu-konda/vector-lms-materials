.\gpio_2.o: gpio_2.c
.\gpio_2.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_2.o: delay.h
.\gpio_2.o: pin_function_defines.h
