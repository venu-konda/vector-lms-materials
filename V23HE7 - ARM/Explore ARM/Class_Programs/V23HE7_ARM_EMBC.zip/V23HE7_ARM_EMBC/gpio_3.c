//gpio_2a.c flash all gpio pins@100ms
#include <LPC21xx.h>
#include "delay.h"
main()
{
	//cfg p0.27-p0.30 as gpio pin func
	//default all other are any way gpio
	PINSEL1=0;
	//cfg all port pins as gpio out pins
	IODIR0=0xFFFFFFFF;
	IODIR1=0xFFFF0000;
	
	while(1)
	{
		IOPIN0^=0xFFFFFFFF;
		IOPIN1^=0xFFFF0000;
		delay_ms(100);
	}
	
}
