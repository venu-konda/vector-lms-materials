//serialize_out1.c
#include "delay.h"
#include <LPC21xx.h>
#include "defines.h"
#define OPIN 1 //p0.1

main()
{
	int i; char sDat='A';
	//cfg p0.1 as gpio out pit
	SETBIT(IODIR0,OPIN);
	for(i=7;i>=0;i--)
	{
	  READWRITEBIT(IOPIN0,OPIN,sDat,i);
	  delay_us(104);
	}
	while(1);
}
