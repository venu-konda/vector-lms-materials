.\pin_function_test.o: pin_function_test.c
.\pin_function_test.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
