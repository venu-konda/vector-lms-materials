.\gpio_1e.o: gpio_1e.c
.\gpio_1e.o: delay.h
.\gpio_1e.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
