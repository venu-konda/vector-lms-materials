.\sws4_al_leds4_al_2.o: SWs4_AL_LEDs4_AL_2.c
.\sws4_al_leds4_al_2.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\sws4_al_leds4_al_2.o: defines.h
