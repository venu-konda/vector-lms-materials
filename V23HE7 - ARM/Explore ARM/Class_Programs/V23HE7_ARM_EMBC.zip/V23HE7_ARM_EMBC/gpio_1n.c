//gpio_1n.c
#include "delay.h"
#include "pin_function_defines.h"
#include "gpio_hal.h"
#define OPIN 7

main()
{
	//cfg p0.7 as gpio out pit
	CfgPortPin(0,OPIN,GPIO_OUT);
	while(1)
	{
	  TogglePortPin(0,OPIN);
	  delay_ms(100);
	}
}
