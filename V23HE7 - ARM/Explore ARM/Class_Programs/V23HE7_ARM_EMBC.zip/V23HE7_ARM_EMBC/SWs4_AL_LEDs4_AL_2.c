//SWs4_AL_LEDs4_AL_2.c
#include <LPC21xx.h>
#include "defines.h"
#define SWs4_AL_0_4  4  //p0.4- p0.7
#define LEDs4_AL_0_8 8  //p0.8 -p0.11

main()
{
	//cfg p0.8 to p0.11 pins as gpio out
	WRITENIBBLE(IODIR0,LEDs4_AL_0_8,15);
	
	while(1)
	{
		WRITENIBBLE(IOPIN0,LEDs4_AL_0_8,READNIBBLE(IOPIN0,SWs4_AL_0_4));
	}
}
