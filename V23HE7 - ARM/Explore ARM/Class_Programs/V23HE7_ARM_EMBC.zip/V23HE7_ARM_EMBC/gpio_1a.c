//gpio_1a.c
#include "pin_function_defines.h"									
#include "delay.h"
#include <LPC21xx.h>

main()
{
	//cfg p0.7 pin as gpio pin
	CfgPortPin(0,7,FUNC1);
	
	//cfg p0.7 as gpio out pit
	IODIR0|=1<<7;
	
	while(1)
	{
	//write '1' onto pin
	IOSET0=1<<7;
	delay_ms(500);
	
	//write '0' onto pin
	IOCLR0=1<<7;
	delay_ms(500);
	}
}
