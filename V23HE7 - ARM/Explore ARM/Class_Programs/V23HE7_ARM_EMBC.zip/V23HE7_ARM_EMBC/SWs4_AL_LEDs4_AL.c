//SWs4_AL_LEDs4_AL.c
#include <LPC21xx.h>
#define SW1_AL_0_4  4  //p0.4
#define SW2_AL_0_5  5  //p0.5
#define SW3_AL_0_6  6  //p0.6
#define SW4_AL_0_7  7  //p0.7
#define LED1_AL_0_8 8  //p0.8
#define LED2_AL_0_9 9  //p0.9
#define LED3_AL_0_10 10  //p0.10
#define LED4_AL_0_11 11  //p0.11

main()
{
	//cfg p0.8 to p0.11 pins as gpio out
	IODIR0|=1<<LED1_AL_0_8|1<<LED2_AL_0_9|
	        1<<LED3_AL_0_10|1<<LED4_AL_0_11;
	
	while(1)
	{
		if(((IOPIN0>>SW1_AL_0_4)&1)==0)
			IOCLR0=1<<LED1_AL_0_8;
		else
			IOSET0=1<<LED1_AL_0_8;
		
		if(((IOPIN0>>SW2_AL_0_5)&1)==0)
			IOCLR0=1<<LED2_AL_0_9;
		else
			IOSET0=1<<LED2_AL_0_9;
		
		if(((IOPIN0>>SW3_AL_0_6)&1)==0)
			IOCLR0=1<<LED3_AL_0_10;
		else
			IOSET0=1<<LED3_AL_0_10;
		
		if(((IOPIN0>>SW4_AL_0_7)&1)==0)
			IOCLR0=1<<LED4_AL_0_11;
		else
			IOSET0=1<<LED4_AL_0_11;
		
		
		
	}
}
