//pin_function_defines.c
#include <LPC21xx.h>
#include "pin_function_defines.h"
void CfgPortPin(unsigned int portNo,
	              unsigned int pinNo,
                unsigned int pinFunc)
{
	if(portNo==0)
	{
		(pinNo<16) ? 
		CFGPIN(PINSEL0,pinNo,pinFunc) : 
		CFGPIN(PINSEL1,pinNo,pinFunc) ;
	}
	else if(portNo==1)
	{
		if(pinNo>15)
		   CFGPIN(PINSEL2,pinNo,pinFunc);
	}
}

void CfgPin(unsigned int pinNo,
	          unsigned int pinFunc)
{
	(pinNo<32) ?
	CfgPortPin(0,pinNo,pinFunc) :
	CfgPortPin(1,(pinNo-16),pinFunc);
}
							
