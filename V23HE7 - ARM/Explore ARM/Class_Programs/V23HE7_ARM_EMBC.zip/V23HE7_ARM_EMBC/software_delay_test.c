//software_delay_test_3.c
#include "delay.h"

main()
{
  delay_us(1000);
	delay_ms(1);
	delay_ms(1000);
	delay_s(1);
  while(1);	
}
