//SWs4_AL_LEDs4_AL_1.c
#include <LPC21xx.h>
#include "defines.h"
#include "types.h"
#define SW1_AL_0_4  4  //p0.4
#define SW2_AL_0_5  5  //p0.5
#define SW3_AL_0_6  6  //p0.6
#define SW4_AL_0_7  7  //p0.7
#define LED1_AL_0_8 8  //p0.8
#define LED2_AL_0_9 9  //p0.9
#define LED3_AL_0_10 10  //p0.10
#define LED4_AL_0_11 11  //p0.11

main()
{
	u32 i;
	//cfg p0.8 to p0.11 pins as gpio out
	WRITENIBBLE(IODIR0,LED1_AL_0_8,15);
	
	while(1)
	{
		for(i=0;i<4;i++)
		READWRITEBIT(IOPIN0,LED1_AL_0_8+i,IOPIN0,SW1_AL_0_4+i);
	}
}
