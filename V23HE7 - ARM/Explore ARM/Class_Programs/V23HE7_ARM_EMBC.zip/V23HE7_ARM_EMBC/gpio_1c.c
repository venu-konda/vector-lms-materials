//gpio_1b.c
#include "delay.h"
#include <LPC21xx.h>

main()
{
	//cfg p0.7 as gpio out pit
	IODIR0|=0x80;
	
	while(1)
	{
	 //write '1' onto pin
	 IOSET0=0x80;
	 delay_ms(500);
	
	 //write '0' onto pin
	 IOCLR0=0x80;
	 delay_ms(500);
	}
}
