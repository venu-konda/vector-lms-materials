.\pattern_0_to_255b.o: pattern_0_to_255b.c
.\pattern_0_to_255b.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\pattern_0_to_255b.o: types.h
.\pattern_0_to_255b.o: delay.h
.\pattern_0_to_255b.o: types.h
.\pattern_0_to_255b.o: defines.h
