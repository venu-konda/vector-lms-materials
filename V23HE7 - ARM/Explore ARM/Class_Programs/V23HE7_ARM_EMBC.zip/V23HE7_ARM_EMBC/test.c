main()
{
  unsigned int dlyUS=1000,dlyMS=1,dlyS=1;
	
  for(dlyUS*=12;dlyUS>0;dlyUS--);
	
	for(dlyMS*=12000;dlyMS>0;dlyMS--);
	
	dlyMS=1000;
	for(dlyMS*=12000;dlyMS>0;dlyMS--);
	
	
	for(dlyS*=12000000;dlyS>0;dlyS--);
	
  while(1);	
}
