//gpio_1e.c
#include "delay.h"
#include <LPC21xx.h>

main()
{
	//cfg p0.7 as gpio out pit
	IODIR0|=0x80;
	
	while(1)
	{
	 //write '1' onto pin
	 IOPIN0^=1<<7;
	 delay_ms(500);
	}
}
