.\gpio_1f.o: gpio_1f.c
.\gpio_1f.o: delay.h
.\gpio_1f.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
