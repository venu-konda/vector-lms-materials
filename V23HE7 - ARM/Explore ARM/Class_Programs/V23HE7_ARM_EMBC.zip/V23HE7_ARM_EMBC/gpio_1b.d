.\gpio_1b.o: gpio_1b.c
.\gpio_1b.o: delay.h
.\gpio_1b.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
