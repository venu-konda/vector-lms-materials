.\gpio_1n.o: gpio_1n.c
.\gpio_1n.o: delay.h
.\gpio_1n.o: types.h
.\gpio_1n.o: pin_function_defines.h
.\gpio_1n.o: gpio_hal.h
.\gpio_1n.o: types.h
