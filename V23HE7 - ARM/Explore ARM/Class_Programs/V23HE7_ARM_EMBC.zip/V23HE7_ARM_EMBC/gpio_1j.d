.\gpio_1j.o: gpio_1j.c
.\gpio_1j.o: delay.h
.\gpio_1j.o: C:\Keil4ARM\ARM\Inc\Philips\LPC21xx.h
.\gpio_1j.o: defines.h
