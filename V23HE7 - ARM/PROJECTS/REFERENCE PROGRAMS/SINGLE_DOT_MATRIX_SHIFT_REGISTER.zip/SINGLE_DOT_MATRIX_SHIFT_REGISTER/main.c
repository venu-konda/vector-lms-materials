#include <LPC21xx.H>
#include "delays.h"
#include "defines.h"
#include "74LS164.h"
#include "dml.h"


int main()
{
	int i;
	IODIR0 = 0x0000ff; //ROWS as output
	Init_74LS164();
	while(1)
		for(i=0;i<26;i++)
			display_char('A'+i,500);
}

