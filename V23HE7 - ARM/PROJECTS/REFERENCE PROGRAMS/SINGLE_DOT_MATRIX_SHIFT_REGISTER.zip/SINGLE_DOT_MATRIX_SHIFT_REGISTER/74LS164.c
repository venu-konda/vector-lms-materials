                       /* 74LS164.c */
#include "defines.h"
#include "delays.h"
#include <LPC21xx.h>


#define SIN  8     //p0.8
#define CP   9     //p0.9


void Init_74LS164(void)
{
	IODIR0 |= (1<<CP|1<<SIN);
}	

void SIPO_74LS164(unsigned char sDat) //Serial In Parallel Out(SIPO) Operations
{
   unsigned char i;
   //SCLRBIT(IOCLR0,_MR);
   //delay_us(1);
   //SSETBIT(IOSET0,_MR);
   //delay_us(1);
	
   for(i=0;i<8;i++)
   {
		   WRITEBIT(IOPIN0,SIN,((sDat>>(7-i))&1));
		   SSETBIT(IOSET0,CP);
		   delay_us(1);
		   SCLRBIT(IOCLR0,CP);
		   delay_us(1);
   }
 }
