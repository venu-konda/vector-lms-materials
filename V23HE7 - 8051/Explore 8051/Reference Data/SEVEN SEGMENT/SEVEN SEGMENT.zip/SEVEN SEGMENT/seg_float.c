#include<reg52.h>

#include "segment.h"

main()
{
	unsigned int k;

	while(1)
	{

		for(k=0;k<500;k++)
			dispf_4_mux_segs(1.245);
	    //--------------------------
		for(k=0;k<500;k++)
			dispf_4_mux_segs(43.89);
	    //--------------------------
		for(k=0;k<500;k++)
			dispf_4_mux_segs(678.7);
	}
}
