#ifndef segment_h
#define segment_h

extern void dispi_4_mux_segs(unsigned int);
extern void dispf_4_mux_segs(float);
extern void dispi_2_mux_segs(unsigned char,bit);

extern void display_help_string(void);

extern void display_help_string_scroll(void);

#endif

