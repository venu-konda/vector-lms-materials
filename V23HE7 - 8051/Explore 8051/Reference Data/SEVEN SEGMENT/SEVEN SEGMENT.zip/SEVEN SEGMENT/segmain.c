#include<reg52.h>

#include "segment.h"

extern unsigned char dp1,dp2,dp3;

main()
{
	unsigned int i,j,k;

	while(1)
	{
		dp1=0xff;dp2=0xff;dp3=0xff;
		//--------------------------
		for(k=0;k<500;k++)
			dispi_4_mux_segs(1245);
	    //--------------------------
		for(k=0;k<500;k++)
			dispf_4_mux_segs(1.245);
	    //--------------------------
		for(k=0;k<500;k++)
			dispf_4_mux_segs(12.45);
	    //--------------------------
		for(k=0;k<500;k++)
			dispf_4_mux_segs(124.5);
	    //--------------------------
		for(k=0;k<500;k++)
			display_help_string();
	   //--------------------------
		for(i=0;i<60;i++)
		{
			for(j=0;j<60;j++)
			{
				for(k=0;k<10;k++)
				{
					dispi_2_mux_segs(j,0);
					dispi_2_mux_segs(i,1);
				}
			}
		}
	}
}
