#include<reg52.h>

#include "segment.h"

main()
{
	while(1)
	{

		display_help_string_scroll();

	}
}
