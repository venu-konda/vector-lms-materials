#include<reg52.h>

#include "segment.h"

main()
{
	unsigned int k;

	while(1)
	{
		for(k=0;k<500;k++)
			dispi_4_mux_segs(1264);

		for(k=0;k<500;k++)
			dispi_4_mux_segs(8745);
	}
}
