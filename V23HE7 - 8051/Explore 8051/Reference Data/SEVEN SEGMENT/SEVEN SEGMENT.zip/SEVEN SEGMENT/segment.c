#include<reg52.h>

#include "delay.h"

#define seg_data P0

sbit sel1 = P2^0;
sbit sel2 = P2^1;
sbit sel3 = P2^2;
sbit sel4 = P2^3;

code unsigned char seg_lut[]={0xc0,0xf9,0xa4,0xb0,0x99,0x92,0x82,0xf8,0x80,0x90};

code unsigned char help_lut[] = {0xff,0xff,0xff,0x89,0x86,0xc7,0x8c,0xff,0xff,0xff};

//code unsigned char seg_lut[]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};

unsigned char dp1=0xff,dp2=0xff,dp3=0xff;


void dispi_4_mux_segs(unsigned int n)
{
	seg_data=seg_lut[n/1000]&dp1;
	sel1=0;
	delay_ms(1);
	sel1=1;
	
	seg_data=seg_lut[(n/100)%10]&dp2;
	sel2=0;
	delay_ms(1);
	sel2=1;
	
	seg_data=seg_lut[(n%100)/10]&dp3;
	sel3=0;
	delay_ms(1);
	sel3=1;
	
	seg_data=seg_lut[(n%10)];	
	sel4=0;
	delay_ms(1);
	sel4=1;

}
void dispf_4_mux_segs(float f)
{
	int t;
	dp1=0xff;dp2=0xff;dp3=0xff;
	if(f>=0.0&&f<10.0)
	{
		t=f*1000;
		dp1=0x7f;
	}
	if(f>=10.0&&f<100.0)
	{
		t=f*100;
		dp2=0x7f;
	}
	if(f>=100.0&&f<1000.0)
	{
		t=f*10;
		dp3=0x7f;
	}

	dispi_4_mux_segs(t);
}

void dispi_2_mux_segs(unsigned char n,bit t)
{
	if(t==0)
	{
		seg_data=seg_lut[n/10];
		sel3=0;
		delay_ms(1);
		sel3=1;
		seg_data=seg_lut[n%10];
		sel4=0;
		delay_ms(1);
		sel4=1;
	}
	else
	{
		seg_data=seg_lut[n/10];
		sel1=0;
		delay_ms(1);
		sel1=1;
		seg_data=seg_lut[n%10];
		sel2=0;
		delay_ms(1);
		sel2=1;
	}
}

void display_help_string()
{
	seg_data=help_lut[0];
	sel1=0;
	delay_ms(1);
	sel1=1;
	
	seg_data=help_lut[1];
	sel2=0;
	delay_ms(1);
	sel2=1;
	
	seg_data=help_lut[2];
	sel3=0;
	delay_ms(1);
	sel3=1;
	
	seg_data=help_lut[3];	
	sel4=0;
	delay_ms(1);
	sel4=1;
}

void display_help_string_scroll()
{
	unsigned char i,j;
	for(i=0;i<7;i++)
	{
		for(j=0;j<100;j++)
		{
			seg_data=help_lut[i];
			sel1=0;
			delay_ms(1);
			sel1=1;
			
			seg_data=help_lut[i+1];
			sel2=0;
			delay_ms(1);
			sel2=1;
			
			seg_data=help_lut[i+2];
			sel3=0;
			delay_ms(1);
			sel3=1;
			
			seg_data=help_lut[i+3];	
			sel4=0;
			delay_ms(1);
			sel4=1;
		}
	}
}
