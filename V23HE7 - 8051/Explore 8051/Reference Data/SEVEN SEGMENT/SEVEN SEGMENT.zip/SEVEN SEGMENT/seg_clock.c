#include<reg52.h>

#include "segment.h"


main()
{
	unsigned int i,j,k;

	while(1)
	{
		for(i=0;i<60;i++)
		{
			for(j=0;j<60;j++)
			{
				for(k=0;k<100;k++)
				{
					dispi_2_mux_segs(j,0);
					dispi_2_mux_segs(i,1);
				}
			}
		}
	}
}
