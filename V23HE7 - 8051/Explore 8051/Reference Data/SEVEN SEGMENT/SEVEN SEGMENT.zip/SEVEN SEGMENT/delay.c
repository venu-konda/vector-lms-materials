
void delay_ms(unsigned int dly)
{
	unsigned char j;
	for(;dly>0;dly--)
	{
		for(j=255;j>0;j--);
		for(j=232;j>0;j--);
	}
}