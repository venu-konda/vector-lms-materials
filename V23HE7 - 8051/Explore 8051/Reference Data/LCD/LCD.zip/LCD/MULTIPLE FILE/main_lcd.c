#include "types.h"
#include "delay.h"
#include "lcd.h"

//main function call
int main()
{
	u16 i;
	LCD_Init();
	Write_DAT_LCD('A');
	Write_CMD_LCD(0x88);
	Write_DAT_LCD(66);
	Write_CMD_LCD(0x8B);
	Write_int_LCD(66);
	Write_CMD_LCD(0xC0);
	Write_DAT_LCD(48);
	Write_CMD_LCD(0xC8);
	Write_DAT_LCD('$');
	Write_str_LCD("INDIA$");
	delay_ms(1000);
	Write_CMD_LCD(0x01);
	for(i=32;i<=255;i++)
	{
		Write_CMD_LCD(0x01);
		Write_int_LCD(i);
		Write_str_LCD("   :  ");
		Write_DAT_LCD(i);
		delay_ms(1000);
	}
	while(1);
}



