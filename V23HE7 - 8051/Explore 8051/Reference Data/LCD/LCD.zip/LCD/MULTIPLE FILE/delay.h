#ifndef _DELAY_H_
#define _DELAY_H_

#include "types.h"
//delay function declaration
void delay_ms(u16);

#endif