#include <REG52.H>

#include "lcd.h"
#include "delay.h"

//LCD Connections
#define LCD_DATA P0		//P0 pins are connected to lcd data pins

sbit RS = P1^0;		//P1.0 is connected to RS of LCD
sbit RW = P1^1;		//P1.1 is connected to RS of LCD
sbit EN = P1^2;		//P1.2 is connected to RS of LCD

//LCD_Init function is used to initialize the LCD
void LCD_Init(void)
{
	delay_ms(16);
	Write_CMD_LCD(0x30);
	delay_ms(5);
	Write_CMD_LCD(0x30);
	delay_ms(1);
	Write_CMD_LCD(0x30);
	delay_ms(1);
	Write_CMD_LCD(0x38);  //set 8-bit mode of operation with 2 lines and 5X7 character font  
	Write_CMD_LCD(0x10);  //Turning OFF the display
	Write_CMD_LCD(0x01);  //clearing the display
	Write_CMD_LCD(0x06);  //Shifting the cursor to the right side after writing each byte onto the display
	Write_CMD_LCD(0x0F);  //Enabling the display with blinking cursor  
				                //once try with 0X0E,0X0C instead of 0x0F	
}

//Write_CMD_LCD function is used to send the command to LCD
void Write_CMD_LCD(u8 cmd)
{
	LCD_DATA = cmd;
  RS = 0;		//RS=0 to select the command/instruction register
	RW = 0;		//RW=0 to write data to the LCD
	EN = 1;		//EN high to low for writing operation
	EN = 0;
	delay_ms(2);	//wait for some time to complete the operation from LCD driver controller
}

//Write_DAT_LCD function is used to display one character on LCD
void Write_DAT_LCD(u8 dat)
{
	LCD_DATA = dat;
  RS = 1;		//RS=1 to select the data register
	RW = 0;		//RW=0 to write data to the LCD
	EN = 1;		//EN high to low for writing operation
	EN = 0;
	delay_ms(2);  //wait for some time to complete the operation from LCD driver controller
}

//Write_str_LCD function is used to display string on LCD
void Write_str_LCD(char *str)
{
	while(*str != '\0')
	{
		Write_DAT_LCD(*str);
		str++;
	}
}

//Write_int_LCD function is used to display the integer value on LCD (integer to ASCII conversion)
void Write_int_LCD(s16 n)
{
	u8 a[10],i=0;
  if(n<0)
	{
		Write_DAT_LCD('-');
		n=-n;
	}
	do                       
	{
		a[i++]=n%10+48;	
		n=n/10;
	}while(n);
  for(;i>0;i--)
		Write_DAT_LCD(a[i-1]);
}



