#ifndef _TYPES_H_
#define _TYPES_H_

//typedef keyword is used to redefine the name of already existing data types
typedef unsigned int u16;
typedef signed int s16;
typedef unsigned char u8;

#endif