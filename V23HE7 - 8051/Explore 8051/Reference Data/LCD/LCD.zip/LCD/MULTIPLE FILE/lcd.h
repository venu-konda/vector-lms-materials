#ifndef _LCD_H_
#define _LCD_H_

#include "types.h"

//LCD functions declaration
void LCD_Init(void);
void Write_CMD_LCD(u8);
void Write_DAT_LCD(u8);
void Write_str_LCD(u8 *);
void Write_int_LCD(s16);

#endif