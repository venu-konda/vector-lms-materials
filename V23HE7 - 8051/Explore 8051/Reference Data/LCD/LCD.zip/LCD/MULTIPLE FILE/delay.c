#include "types.h"

//delay_ms function is used to create the delay based on valur passed to this function as an argumant
void delay_ms(u16 dly)
{
	u8 i;
  for(;dly>0;dly--)
  {
  	for(i=250;i>0;i--);
  	for(i=232;i>0;i--);
  }
}