#include<reg52.h>

sbit led1 = P1^0;
sbit led2 = P1^1;


void ext_int0(void) interrupt 0
{
	led1 = ~led1;	
	led1 = ~led1;	
	led1 = ~led1;	
	led1 = ~led1;	
}

void ext_int1(void) interrupt 2
{
	led2 = ~led2;	
	led2 = ~led2;
	led2 = ~led2;
	led2 = ~led2;
}

main()
{
	unsigned char i=0x01;

	EA=EX0=EX1=1;
//	IT0=0;IT1=0;//level trigger	interrupt
	IT0=1;IT1=1;//edge trigger interrupt
	PX1 = 1;
//	PX0 = 1;
	
	while(1)
	{
		i = i<<1;
		P2 = i;
		if(i==0x80)	
			i=0x01;	
	}

}
