#include<reg52.h>

sbit led = P0^0;

void timer0_int(void) interrupt 1
{
	led = ~led;
	TH0 = (7192>>5)&0xFF;
	TL0 = (7192&0X1F);
}


main()
{
	unsigned char i=0x01;

	EA=ET0=1;//timer0 interrupt is enabled

	TMOD = 0X00;
	TH0 = (7192>>5)&0xFF;
	TL0 = (7192&0X1F);
	TR0 = 1;
	
	while(1)
	{
		P1 = i;
		i = i<<1;		
		if(i==0x80)	
			i=0x01;	
	}

}
