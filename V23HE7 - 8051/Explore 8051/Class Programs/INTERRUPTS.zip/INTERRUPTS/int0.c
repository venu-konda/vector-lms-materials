#include<reg52.h>

sbit led = P1^0;

void ext_int0(void) interrupt 0
{
	led = ~led;	
}
main()
{
	unsigned char i=0x01;
	EA=EX0=1;
	//IT0=0; //level trigger - low level trigger
	IT0=1; //edge trigger - falling edge trigger
	while(1)
	{
		i = i<<1;
		P2 = i;
		if(i==0x80)	
			i=0x01;

	}
}
