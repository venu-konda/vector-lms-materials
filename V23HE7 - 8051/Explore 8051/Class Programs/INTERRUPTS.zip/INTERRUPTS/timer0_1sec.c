#include<reg52.h>

sbit led = P0^0;
unsigned char cnt = 0;

void timer0_int(void) interrupt 1
{
	cnt++;
	if(cnt==20)
	{
		led = ~led;
		cnt=0;
	}

	led = ~led;
	TH0 = (15536>>8)&0xFF;
	TL0 = 15536;
}


main()
{
	unsigned char i=0x01;

	EA=ET0=1;//timer0 interrupt is enabled

	TMOD = 0X01;
	TH0 = (15536>>8)&0xFF;
	TL0 = 15536;
	TR0 = 1;
	
	while(1)
	{
		P1 = i;
		i = i<<1;		
		if(i==0x80)	
			i=0x01;	
	}

}
