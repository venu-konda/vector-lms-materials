#include<reg52.h>

sbit led = P1^0;


void ext_int1(void) interrupt 2
{
	led = ~led;	
}



main()
{
	unsigned char i=0x01;

	EA=EX1=1;
	IT1=0; //level trigger
	//IT1=1;	//edge trigger
	while(1)
	{
		i = i<<1;
		P2 = i;
		if(i==0x80)	
			i=0x01;	
	}

}
