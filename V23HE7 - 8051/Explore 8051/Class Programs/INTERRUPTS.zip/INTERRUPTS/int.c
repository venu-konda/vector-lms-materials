#include<reg52.h>
/*
Interrupt	-	I.Identifier-	vector address
----------------------------------------------
INT0		-		0		-		0x0003
TIMER0		-		1		-		0x000B
INT1		-		2		-		0X0013
TIMER1		-		3		-		0X001B
UART INT	-		4		-		0X0023
----------------------------------------------		
void isr_name(void) interrupt InterruptIdentifier
{

}
*/

//interrupt service routine syntax
void ext_int0(void) interrupt 0
{
}
void timer0_int(void) interrupt 1
{
}
void ext_int1(void) interrupt 2
{
}
void timer1_int(void) interrupt 3
{
}
void serial_int(void) interrupt 4
{
}

main()
{
	unsigned char i=0x01;
	
	while(1)
	{
		i = i<<1;
		P1 = i;	
	}

}
