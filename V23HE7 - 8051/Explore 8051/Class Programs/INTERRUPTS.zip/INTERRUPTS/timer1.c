#include<reg52.h>

sbit led = P0^0;


void timer1_int(void) interrupt 3
{
	led = ~led;
	TH1 = (7192>>5)&0xFF;
	TL1 = (7192&0X1F);
}


main()
{
	unsigned char i=0x01;

	EA=ET1=1;//timer1 interrupt is enabled

	TMOD = 0X00;
	TH1 = (7192>>5)&0xFF;
	TL1 = (7192&0X1F);
	TR1 = 1;
	
	while(1)
	{
		i = i<<1;
		P1 = i;
		if(i==0x80)	
			i=0x01;	
	}

}
