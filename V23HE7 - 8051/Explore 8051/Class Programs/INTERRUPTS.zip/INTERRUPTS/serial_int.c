#include<reg52.h>

/** global variables declaration **/
bit r_flag,t_flag;
unsigned char ch=0,k,rec_buff[25];

void uart_init(void);
void uart_tx(unsigned char);
void uart_string(unsigned char *);
void delay_ms(unsigned int);


/** serial interrupt routine **/
void serial_int(void) interrupt 4
{
	if(TI == 1)	//if TI flag set
	{	
		t_flag = 1;
		TI = 0;	//clear TI bit to identifying next character sending
	}
	else if(RI==1) //if RI flag set
	{
		ch = SBUF;	//collect the received data byte
		if(ch == 0x0d)	//0x0d - for enter or '$' for string termination
		{
			r_flag=1;	//used for identifing the end of the string entry		
			rec_buff[k] = '\0';
			k=0;
		}
		else 
			rec_buff[k++] = ch;	//svae the collected byte in to rec_buff
		RI = 0;	//claer RI bit to identify the next byte receive		
	}
}


main()
{
	uart_init();
	while(1)
	{
		do
		{
			uart_string("INDIA\r\n");
			delay_ms(1000);	
		}while(r_flag==0);
		r_flag=0;
		uart_string(rec_buff);
		delay_ms(5000);
		while(1);

	}
}

/** uart initialization **/
void uart_init(void)
{
	TMOD = 0X20;	//timer1, mode2 (auto reloaded mode)
	SCON = 0X50;	//select standard UART mode (mode1) 
					//serial mode1, 8-bi data,1 stop bit,1 start bit 
	TH1 = 0XFD;		//9600 baudrate selection
	TR1 = 1;		//timer1 on
	IE = 0X90;		//enable serial port interrupt
	//EA=ES=1;
}

/** sending one character through uart **/
void uart_tx(unsigned char dat)
{
	t_flag = 0;	//clear t_flag variable
	SBUF = dat;	//place one byte data into SBUF register
	while(t_flag == 0);	//waiting for transmit complete
}

/** send string through uart*/
void uart_string(unsigned char *str)
{
	while(*str)	//sending character by character till null
		uart_tx(*str++);	//sending one character through uart
}

void delay_ms(unsigned int ms)
{
	unsigned int i;
	for (;ms>0;ms--)
		for(i=123;i>0;i--);
}
