#include<reg51.h>


/*
TIMER0 MODE0 AS COUNTER0 SELECTION
C/T(bar) = 0, MEANS TIMER OPERATION SELECTED
C/T(bar) = 1, MEANS COUNTER OPERATION SELECTED
TMOD REGISTER:
GATE C/T M1 M0 GATE C/T M1 M0
  0   0  0  0   0    1  0   0 = 0X04
*/
main()
{
	unsigned char cnt=0;

	TMOD = 0x04;//timer0,mode0 as counter
	TH0 = 0x00;
	TL0 = 0x00;
	TR0 = 1;
	while(1)
	{	
		cnt = (TH0*32) + TL0;	
		//cnt = (TH0<<5) | (TL0&0x1F);
		P0 = cnt;
	}
}

