#include<reg51.h>

/*
TIMER1 MODE0 AS COUNTER0 SELECTION
C/T(bar) = 0, MEANS TIMER OPERATION SELECTED
C/T(bar) = 1, MEANS COUNTER OPERATION SELECTED
TMOD REGISTER:
GATE C/T M1 M0 GATE C/T M1 M0
  0   1  0  0   0    0  0   0 = 0X40
*/



main()
{
	unsigned char cnt=0;

	TMOD = 0x40;	//timer0,mode0 as counter
	TH1 = 0x00;
	TL1 = 0x00;
	TR1 = 1;
	while(1)
	{
	
		cnt = (TH1*32) + TL1;	
	
		P0 = cnt;
	
	}
	

}

