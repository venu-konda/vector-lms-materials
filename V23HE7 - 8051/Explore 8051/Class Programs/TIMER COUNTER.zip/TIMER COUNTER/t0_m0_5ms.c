#include<reg51.h>
#include<intrins.h>

sbit led = P1^0;

//8192-5000=3192
//3192+15=3207 (1 1 0 0 1 0 0 0 0 1 1 1)

void timer0_mode0_5ms()
{
	TMOD = 0X00;
	TH0 = 0X64;
	TL0 = 0X07;
	TR0 = 1;
	while(TF0==0);
	TF0 = 0;
	TR0 = 0;
	_nop_();
}

main()
{

	while(1)
	{
		led = ~led;
		timer0_mode0_5ms();
	
	}
	

}

