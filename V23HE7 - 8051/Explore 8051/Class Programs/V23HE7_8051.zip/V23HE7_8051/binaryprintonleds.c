#include <reg51.h>

#define LEDS P2

#include "delay.h"

#define AHLEDS 1
#define ALLEDS 2
#define AHALLEDS 3

#define BOARD_CONNECTION AHALLEDS

main()
{
	unsigned char i;
#if(BOARD_CONNECTION==AHLEDS)

	for(i=0;i<255;i++)
	{
		LEDS = i;
		delay_ms(1000);		
	}
	LEDS = i;
#elif(BOARD_CONNECTION==ALLEDS)
	for(i=0;i<255;i++)
	{
		LEDS = ~i;
		delay_ms(1000);		
	}
	LEDS = ~i;
#elif(BOARD_CONNECTION==AHALLEDS)
	for(i=0;i<255;i++)
	{
		LEDS = i^0x0F;
		delay_ms(1000);		
	}
	LEDS = i^0x0F;
#endif
	while(1);

}
