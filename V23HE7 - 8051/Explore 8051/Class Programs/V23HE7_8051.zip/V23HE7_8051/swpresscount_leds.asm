SW EQU P1.0
LEDS EQU P2

CSEG AT 0
ACALL DELAY_1000MS
MOV 20H,#00;used for holding the switch press count value
LOOP:
L1:JB SW,L1;waiting for switch press
INC 20H;increment the switch press count value
L2:JNB SW,L2;waiting for switch release
ACALL DELAY_100MS
MOV LEDS,20H;update switch press count value on P2
SJMP LOOP

DELAY_1MS:
MOV R7,#255
DJNZ R7,$
MOV R7,#242
DJNZ R7,$
RET 

DELAY_10MS:
MOV R6,#10
K1:ACALL DELAY_1MS
DJNZ R6,K1
RET

DELAY_100MS:
MOV R5,#10
K2:ACALL DELAY_10MS
DJNZ R5,K2
RET

DELAY_1000MS:
MOV R4,#10
K3:ACALL DELAY_100MS
DJNZ R4,K3
RET


END
