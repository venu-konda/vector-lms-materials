#include <reg51.h>

sbit SW = P1^0; //Active low switch is connected to P1.0

#define LEDS P2 //8 active high leds are connted to P2


main()
{
	unsigned int sw_count=0;

	while(1)
	{
		if(SW == 0)
		{
			sw_count++;
			while(SW==0);
		}
		LEDS = sw_count;
	}
}
