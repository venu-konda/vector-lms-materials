#include <reg51.h>

void UART_Init()
{
	SCON = 0x50;
	TMOD = 0x20;
	TH1 = 253;
	TL1 = 253;
	TR1 = 1;
}

void UART_Txchar(unsigned char ch)
{
	SBUF = ch;
	while(TI == 0);
	TI = 0;
}

unsigned char UART_Rxchar()
{
	while(RI == 0);
	RI = 0;
	return SBUF;
}


main()
{
	UART_Init();
	while(1)
	{
		UART_Txchar(UART_Rxchar());

	}	
}

